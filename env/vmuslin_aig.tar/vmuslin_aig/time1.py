import sys
from time import *

offset=int(sys.argv[1])
print offset
lt=localtime(time()+offset)

print '%02d %02d %04d %02d %02d %02d' % (lt[1], lt[2], lt[0], lt[3], lt[4], lt[5])
