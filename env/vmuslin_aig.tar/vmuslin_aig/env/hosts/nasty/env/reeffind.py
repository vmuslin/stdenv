#!/usr/bin/python

import os, sys

SRCTOP = os.environ["HOME"] + "/dev/src/P/reef"
REGEXP = sys.argv[1]
FILES  = sys.argv[2]

command = "find $(ls %s | grep -v dist | tr '\n' ' ') -name \"%s\" -print | xargs grep %s" % (SRCTOP, FILES, REGEXP)
os.chdir(SRCTOP)
os.system(command)

